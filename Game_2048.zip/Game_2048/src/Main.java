import java.util.*;

class Game2048
{
    public void rightMove(int [][]arr)
    {
        for(int i=0;i<arr.length;i++)
        {
            for(int j=arr.length-1;j>=0;j--)
            {
                boolean flag = false;
                if(arr[i][j] != 0)
                {
                    for(int k=j;k<arr.length-1;k++)
                    {
                        if(arr[i][k] == arr[i][k+1] && !flag)
                        {
                            arr[i][k+1] = arr[i][k] + arr[i][k+1];
                            arr[i][k] = 0;
                            flag = true;
                            break;
                        }
                        else if(arr[i][k+1] == 0)
                        {
                            arr[i][k+1] = arr[i][k];
                            arr[i][k] = 0;
                        }
                    }
                }
            }
        }
    }
    public void leftMove(int [][]arr)
    {

        for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<arr.length;j++)
            {
                boolean flag = false;
                if(arr[i][j] != 0)
                {
                    for(int k=j;k>0;k--)
                    {
                        if(arr[i][k] == arr[i][k-1] && !flag)
                        {
                            arr[i][k-1] = arr[i][k] + arr[i][k-1];
                            arr[i][k] = 0;
                            flag = true;
                            break;
                        }
                        else if(arr[i][k-1] == 0)
                        {
                            arr[i][k-1] = arr[i][k];
                            arr[i][k] = 0;
                        }
                    }
                }
            }
        }
    }
    public void moveUp(int [][]arr)
    {
        for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<arr.length;j++)
            {
                boolean flag = false;
                if(arr[j][i] != 0)
                {
                    for(int k=j;k>0;k--)
                    {
                        if(arr[k][i] == arr[k-1][i] && !flag)
                        {
                            arr[k-1][i] = arr[k][i] + arr[k-1][i];
                            arr[k][i] = 0;
                            flag = true;
                            break;
                        }
                        else if(arr[k-1][i] == 0)
                        {
                            arr[k-1][i] = arr[k][i];
                            arr[k][i] = 0;
                        }
                    }
                }
            }
        }
    }
    public void moveDown(int [][]arr)
    {
        for(int i=0;i<arr.length;i++)
        {
            for(int j=arr.length-1;j>=0;j--)
            {
                boolean flag = false;
                if(arr[j][i] != 0)
                {
                    for(int k=j;k<arr.length-1;k++)
                    {
                        if(arr[k][i] == arr[k+1][i] && !flag)
                        {
                            arr[k+1][i] = arr[k+1][i] + arr[k][i];
                            arr[k][i] = 0;
                            flag = true;
                            break;
                        }
                        else if(arr[k+1][i] == 0)
                        {
                            arr[k+1][i] = arr[k][i];
                            arr[k][i] = 0;
                        }
                    }
                }
            }
        }
    }
    public void generateRandomNumber(int [][]arr)
    {
        Random random = new Random();
        while(true)
        {
            int row = random.nextInt(4);
            int col = random.nextInt(4);
            if(arr[row][col] == 0)
            {
                arr[row][col] = 2;
                break;
            }
        }
    }

    public void printGame(int [][]arr)
    {
        System.out.println("---------------");
        for(int i=0;i<arr.length;i++)
        {
            System.out.print("| ");
            for(int j=0;j<arr.length;j++)
            {
                System.out.print(arr[i][j]+"  ");
            }
            System.out.print("|");
            System.out.println();
        }
        System.out.println("---------------");
    }
}
public class Main
{
    public static void main(String []args)
    {
        Scanner in = new Scanner(System.in);
        Game2048 game = new Game2048();
        int [][]matrix = new int[4][4];
        matrix[0][2] = 2;
        matrix[3][3] = 2;
        game.printGame(matrix);
        boolean flag = true;
        while(flag)
        {
            System.out.println(" 1.Move Right    2.Move Left    3.Move Up    4.Move Down    5.Exit");
            System.out.println("Enter the choice : ");
            int choice = in.nextInt();
            switch(choice)
            {
                case 1:
                {
                    game.rightMove(matrix);
                    game.generateRandomNumber(matrix);
                    game.printGame(matrix);
                    break;
                }
                case 2:
                {
                    game.leftMove(matrix);
                    game.generateRandomNumber(matrix);
                    game.printGame(matrix);
                    break;
                }
                case 3:
                {
                    game.moveUp(matrix);
                    game.generateRandomNumber(matrix);
                    game.printGame(matrix);
                    break;
                }
                case 4:
                {
                    game.moveDown(matrix);
                    game.generateRandomNumber(matrix);
                    game.printGame(matrix);
                    break;
                }
                case 5:
                {
                    flag = false;
                }
            }
        }
    }
}










