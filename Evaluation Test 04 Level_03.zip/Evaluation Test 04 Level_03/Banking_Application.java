import java.io.*;
import java.util.*;
class Bank implements Serializable
{
	static int id1 = 11;
	static int id2 = 10000;
	private int customerId;
	private int accountNo;
	private String customerName;
	private double balance;
	private String encryptedPassword;

	public Bank(String customerName, double balance, String encryptedPassword)
	{
		this.customerId = id1;
		this.accountNo = id2;
		this.customerName = customerName;
		this.balance = balance;
		this.encryptedPassword = encryptedPassword;
		id1 = id1 + 10;
		id2 = id2 + 1000;
	}
	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	public void setEncryptedPassword(String encryptedPassword)
	{
		this.encryptedPassword = encryptedPassword;
	}
	public int getCustomerId()
	{
		return customerId;
	}
	public int getAccountNumber()
	{
		return accountNo;
	}
	public String getCustomerName()
	{
		return customerName;
	}
	public double getBalance()
	{
		return balance;
	}
	public String getPassword()
	{
		return encryptedPassword;
	}
	
}
class BankProcess implements Serializable
{
	Bank bank = null;
	static int transId = 1;
	List<Bank> customers = new ArrayList<>();
	String allDetails = "";
	Map<Integer, List<String>> transactionDetails = new HashMap<>();
	String path = "C:\\Users\\Administrator\\Desktop\\sathish\\All Test\\Evaluation Test 04 Level_03\\bank_db.txt";
	
	public void addCustomers(String name, String password, double balance)
	{
		bank = new Bank(name, balance, password);
		customers.add(bank);
		allDetails = transId + "   " + "  Opening  " +  balance + "   " + balance;
		addTransactionDetails(bank.getCustomerId(), allDetails);
		System.out.println("Bank account successfully created...");
		System.out.println("Customer Id : "+bank.getCustomerId());
		System.out.println("Account Number : "+bank.getAccountNumber());
		writeFile(path);
	}
	
	public void depositAmount(int accountNo, double amount)
	{
		boolean flag = false;
		for(Bank list : customers)
		{
			if(list.getAccountNumber() == accountNo)
			{
				flag = true;
				list.setBalance(list.getBalance()+amount);
				allDetails = transId + "   " + "   CashDeposit   " + amount + "   " + list.getBalance();
				addTransactionDetails(list.getCustomerId(), allDetails);
				System.out.println("Amount successfully deposited...");
				System.out.println("Your available balance : "+list.getBalance());
				writeFile(path);
				break;
			}
		}
		if(!flag)
			System.out.println("No bank account found");
	}	
	public void withdrawAmount(int accountNo, double amount, Scanner in)
	{
		boolean flag = false;
		for(Bank list : customers)
		{
			if(list.getAccountNumber() == accountNo)
			{
				if(list.getBalance() >= amount)
				{
					if(list.getBalance() - amount < 1000)
					{
						System.out.println("You should maintain minimum balance didn't maintain the minimum balance penalty will be applied");
						System.out.println("You want to continue 1.Yes 2.No");
						int x = in.nextInt();
						if(x == 2)
						{
							break;
						}
					}
					list.setBalance(list.getBalance()-amount);
					allDetails = transId + "   " + "   CashDeposit   " + amount + "   " + list.getBalance();
					addTransactionDetails(list.getCustomerId(), allDetails);
					System.out.println("Amount successfully withdrawn...");
					System.out.println("Your available balance : "+list.getBalance());
					writeFile(path);
				}
				break;
			}
		}
	}

	public void printCustomers()
	{
		customers = readFile(path);
		for(Bank list : customers)
		{
			System.out.println(list.getCustomerId()+"   "+list.getAccountNumber()+"   "+list.getCustomerName()+"   "+list.getBalance());
		}
	}
	public void printTransactionDetails(int customerId)
	{
		List<String> list = new ArrayList<>();
		list = transactionDetails.get(customerId);
		for(String l : list)
		{
			System.out.println(l);
		}
	}
	public void initializeCustomers()
	{
		bank = new Bank("Kumar", 10000, "ApipNbjm");
		customers.add(bank);
		String details = transId+"   "+" Opening  " + "  10000  " + bank.getBalance();
		addTransactionDetails(bank.getCustomerId(), details);
		
		bank = new Bank("Madhu", 20000, "Cbojoh");
		customers.add(bank);
		details = transId+"   "+"  Opening  " + "  10000   " + bank.getBalance();
		addTransactionDetails(bank.getCustomerId(), details);

		bank = new Bank("Rahul", 30000, "dbnqvt");
		customers.add(bank);
		details = transId+"   "+"  Opening   " + "  10000  " + bank.getBalance();
		addTransactionDetails(bank.getCustomerId(), details);

		bank = new Bank("Robin", 40000, "kbwb22");
		customers.add(bank);
		details = transId+"   "+" Opening   " + "      10000     " + bank.getBalance();
		addTransactionDetails(bank.getCustomerId(), details);

		writeFile(path);
	}
	public void addTransactionDetails(int customerId, String details)
	{
		if(transactionDetails.containsKey(customerId))
		{
			transactionDetails.get(customerId).add(details);
		}
		else
		{
			transactionDetails.put(customerId, new ArrayList<>());
			transactionDetails.get(customerId).add(details);
		}
		transId++;
	}
	public void writeFile(String path)
	{
		try
		{
			ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(path));		
			writer.writeObject(customers);
			writer.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public List<Bank> readFile(String path)
	{
		try
		{
			ObjectInputStream reader = new ObjectInputStream(new FileInputStream(path));
			customers = (List<Bank>) reader.readObject();
			reader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return customers;

	}
	
}

class Main 
{
	public static void main(String []args)
	{
		String path = "C:\\Users\\Administrator\\Desktop\\sathish\\All Test\\Evaluation Test 04 Level_03\\bank_db.txt";
		File file = new File(path);
		try
		{
			if(file.createNewFile())
			{
				System.out.println("File is created");
			}
			else	
			{
				System.out.println("File already existed");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BankProcess bankProcess = new BankProcess();
		bankProcess.initializeCustomers();
		Scanner in = new Scanner(System.in);
		boolean flag = true;
		while(flag)
		{
			System.out.println(" 1.Add new customer \n 2.Print Customer Details \n 3.ATM \n 4.print transaction details \n 5.Exit");
			System.out.println("Enter the choice : ");
			int choice = in.nextInt();
			switch(choice)
			{
				case 1:
				{
					System.out.println("Enter your name : ");
					String name = in.next();
					String password1 = "";
					while(true)
					{
						System.out.println("Enter the password : ");
						password1 = in.next();
						System.out.println("Enter the password again : ");
						String password2 = in.next();
						if(password1.equals(password2))
							break;
						else
							System.out.println("Password mismatching enter again ");
					}
					bankProcess.addCustomers(name, password1, 10000.0);
					break;
				}
				case 2:
				{
					bankProcess.printCustomers();
					break;
				}
				case 3:
				{
					System.out.println(" 1.Cash Deposit \n 2.ATM withdrawl  \n 3.Account Transfer \n 4.Exit");
					choice = in.nextInt();
					switch(choice)
					{
						case 1:
						{
							System.out.println("Enter the account number : ");
							int accountNo = in.nextInt();
							System.out.println("Enter the deposit balance : ");
							double balance = in.nextDouble();
							bankProcess.depositAmount(accountNo, balance);
							break;
						}
						case 2:
						{
							System.out.println("Enter the account number : ");
							int accountNo = in.nextInt();
							System.out.println("Enter the deposit balance : ");
							double balance = in.nextDouble();
							bankProcess.withdrawAmount(accountNo, balance, in);
							
							break;
						}
						case 3:
						{
							
							break;
						}
						case 4:
						{
							break;
						}
					}
					
					break;
				}
				case 4:
				{
					System.out.println("Enter the customer id : ");
					int customerId = in.nextInt();
					bankProcess.printTransactionDetails(customerId);
					break;
				}
				case 5:
				{
					flag = false;
					break;
				}
				default:
				{
					System.out.println("Invalid choice");
				}
			}
		}
	}
}




